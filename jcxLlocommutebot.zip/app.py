import discord, pyrebase, string, random
from discord.ext import tasks
from github import Github
from github import Auth

config = {
    "apiKey": "AIzaSyDBtv8YKLziMcpHj9hc7nMONe6a1OCp7go",
    "authDomain": "landinginfo-452b6.firebaseapp.com",
    "databaseURL": "https://landinginfo-452b6-default-rtdb.asia-southeast1.firebasedatabase.app",
    "storageBucket": "landinginfo-452b6.appspot.com"
}

firebase = pyrebase.initialize_app(config=config)
db = firebase.database()

def generate_random_id():
    allstrings = string.ascii_letters
    splittedstrings = []
    for str in allstrings:
        splittedstrings.append(str)
    random.shuffle(splittedstrings)
    genfront = ""
    for val in splittedstrings[:8]:
        genfront = genfront + val
    return genfront

def readorders():
    with open("orders.txt", 'r') as orderfile:
        orderdetails = orderfile.read()
    return orderdetails

def writeorder(orders):
    with open('orders.txt', 'w') as orderfile:
        orderfile.write(orders)

client = discord.Client(intents=discord.Intents.all())

@tasks.loop(seconds=5)
async def checkOrder():
    allorders = db.child("orders").get()
    orderkeys = []
    for order in allorders:
        orderkeys.append(order.key())
    redefinedorders = readorders().split(",")
    for ord in list(orderkeys):
        for preord in redefinedorders:
            if ord == preord:
                orderkeys.remove(ord)
    preorders = readorders()
    for leftorder in orderkeys:
        requiredorder = db.child("orders").child(leftorder).get()
        requiredproduct = db.child("links").child(requiredorder.val()['productid']).get()
        generalchannel = client.get_channel(1164936357613940838)
        await generalchannel.send(f"A new order has come!!!\n\nBuyer Details:\nName: {requiredorder.val()['username']}\nEmail: {requiredorder.val()['email']}\nUPI ID: {requiredorder.val()['upiid']}\n\nBuyer wants to purchase: \nProduct ID: {requiredorder.val()['productid']}\nProduct Name: {requiredproduct.val()['productname']}\nProduct Price: ₹{requiredproduct.val()['productprice']}\n\nCheck kro ki payment aaya hai na nhi ye UPI ID se, agar aaya hai to ye link share krdo usko: {requiredproduct.val()['productlink']}")
        if preorders == "":
            preorders = leftorder
        else:
            preorders = preorders + "," + leftorder
        writeorder(preorders)

@tasks.loop(seconds=10)
async def cleanFileStorage():
    siteconfig = {
    "apiKey": "AIzaSyDamV1voIThfnnAxyG3J9LtP4FTdeGhDYk",
    "authDomain": "tindo-de086.firebaseapp.com",
    "databaseURL": "https://tindo-de086-default-rtdb.asia-southeast1.firebasedatabase.app",
    "storageBucket": "tindo-de086.appspot.com",
    "serviceAccount": "tindo-de086-firebase-adminsdk-nmefh-76be52adf7.json"
    }
    WHITELISTED = ["uqkMYcuser.png", "pdf.png", "mVovyffile.png", "_config.yml"]
    fb = pyrebase.initialize_app(siteconfig)
    sitedb = fb.database()
    gitauth = Auth.Token("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")
    git = Github(auth=gitauth)
    repo = git.get_user().get_repo("commutefiles")
    sitechannel = client.get_channel(1168187761514250421)

    allfiles = repo.get_contents("/", "master")
    uploadedfiles = []
    print("Files in github server: ")
    for file in allfiles:
        if '.' in file.path and file.path not in WHITELISTED:
            uploadedfiles.append(file)
            print(file.path)
    print("\n")
    requiredmsgs = []
    allmessagesindb = sitedb.child("messages").get()
    print("Files used in inbox messages: ")
    for msg in allmessagesindb:
        if '****pdf****' in msg.val()['msg'] or '****content****' in msg.val()['msg'] or '****image****' in msg.val()['msg']:
            requiredmsgs.append(msg.val()['msg'].split("/")[-1])
            print(msg.val()['msg'].split("/")[-1])
    print("\n")
    requiredprofilepics = []
    allusers = sitedb.child("users").get()
    print("Files used as profile pictures:")
    for usr in allusers:
        requiredprofilepics.append(usr.val()['profile_pic'].split("/")[-1])
        print(usr.val()['profile_pic'].split("/")[-1])
    print("\n")
    communitydps = []
    allcommunities = sitedb.child("communities").get()
    print("Files used as community dp:")
    for comm in allcommunities:
        communitydps.append(comm.val()['image'].split("/")[-1])
        print(comm.val()['image'].split("/")[-1])
    print("\n")
    requiredcommmsgs = []
    print("Files used in community messages: ")
    for comm in allcommunities:
        commmsgs = comm.val()['messages']
        for key, val in commmsgs.items():
            if '****pdf****' in val['msg'] or '****content****' in val['msg'] or '****image****' in val['msg']:
                requiredcommmsgs.append(val['msg'].split("/")[-1])
                print(val['msg'].split("/")[-1])
    print("\n\n")
    print("Files to keep: ")
    for upfile in list(uploadedfiles):
        for dbfile in requiredmsgs:
            if upfile.path == dbfile:
                uploadedfiles.remove(upfile)
                print(upfile.path)
        for pfile in requiredprofilepics:
            if upfile.path == pfile:
                uploadedfiles.remove(upfile)
                print(upfile.path)
        for cfile in communitydps:
            if upfile.path == cfile:
                uploadedfiles.remove(upfile)
                print(upfile.path)
        for cms in requiredcommmsgs:
            if upfile.path == cms:
                uploadedfiles.remove(upfile)
                print(upfile.path)
    print("\n")
    print("Removing files...")
    if uploadedfiles == []:
        print("No files to delete... Quitting Program!")
    else:
        await sitechannel.send("Waste files found in FileServer!")
        for file in uploadedfiles:
            repo.delete_file(path=file.path, message="Deleting unused file", branch="master", sha=file.sha)
            print("Removed: "+file.path)
            await sitechannel.send("Removed: "+file.path)



@client.event
async def on_ready():
    print("CommuteBot is Online!")
    checkOrder.start()

@client.event
async def on_message(msg):
    if msg.author == client.user:
        return
    if msg.content.lower() == "hello" or msg.content.lower() == "hii":
        await msg.channel.send("Haa bol be! Kya baat hai? Database mein link add krna hai to ye chiz type kar, and description type krte huye same line mein hi sbkuchh likhna, line change mat krna:\n\nPRODUCT\nName= \nLink= \nPrice= \nDescription= \n")
    elif "product" in msg.content.lower():
        content = msg.content
        linesplitting = content.split('\n')
        productname = linesplitting[1].split("=")[-1]
        productlink = linesplitting[2].split("=")[-1]
        productprice = linesplitting[3].split("=")[-1]
        productdesc = linesplitting[4].split("=")[-1]
        alllinks = db.child("links").get()
        
        randomid = generate_random_id()
        while randomid in alllinks.key():
            randomid = generate_random_id()
        
        db.child("links").child(randomid).set({"productname": productname, "productlink": productlink, "productprice": productprice, "productdesc": productdesc})
        await msg.channel.send(f"Product ko add krdiya hai! Ye raha product ka share link: https://commutemanagement.pythonanywhere.com/pd/{randomid}")
        

token = "MTE2NDkzMTUxNjA2MTcyNDgzMw.G-tPO_.kvaPSU8Qo7AVtGy2ZC_zgNQH8f49KNS3QqdALQ"

if __name__ == "__main__":
    client.run(token)